package com.library.library_project.Internal.Handlers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;


import com.library.library_project.Internal.Models.TypeRoles;
import com.library.library_project.Internal.Services.UsersServices;

@RestController
@RequestMapping("/auth")
public class AuthContoller {

    @Autowired
    private UsersServices usersServices;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        String role = request.getOrDefault("role", "ROLE_USER");
        TypeRoles typeRole;
        try {
            typeRole = TypeRoles.valueOf(role);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Rol inválido");
        }

        return ResponseEntity.ok(usersServices.registerUsers(username, password, typeRole));
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");

        Optional<String> token = usersServices.loginUser(username, password);

        if (token.isPresent()) {
            return ResponseEntity.ok(Map.of("token", token.get()));
        } else {
            return ResponseEntity.status(401).body("Credenciales incorrectas");
        }
    }

    
}
