package com.library.library_project.Internal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.library_project.Internal.Models.Books;

public interface BooksRepository extends JpaRepository<Books, Long>{
    List<Books> findByTitleContainingIgnoreCase(String title);

    List<Books> findByAuthorContainingIgnoreCase(String author);

    List<Books> findByGenreContainingIgnoreCase(String genre);

    List<Books> findByYear(int year);

    List<Books> findByAvailable(boolean available);
}
