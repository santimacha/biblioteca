package com.library.library_project.Internal.Models;

public enum TypeRoles {
    ROLE_USER,
    ROLE_ADMIN
}
