package com.library.library_project.Internal.Handlers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.library.library_project.Internal.Models.Loan;
import com.library.library_project.Internal.Services.LoansServices;

@RestController
@RequestMapping("/loans")
public class LoanController {
    
    private final LoansServices loansServices;

    public LoanController(LoansServices loansServices) {
        this.loansServices = loansServices;
    }

    @PostMapping("/borrow")
    public ResponseEntity<Loan> borrowBook(@RequestParam Long userId, @RequestParam Long bookId) {
        return ResponseEntity.ok(loansServices.borrowBook(userId, bookId));
    }

    @PutMapping("/return")
    public ResponseEntity<Loan> returnBook(@RequestParam Long loanId) {
        return ResponseEntity.ok(loansServices.returnBook(loanId));
    }

    @GetMapping("/byBookId")
    public ResponseEntity<Loan> getLoanByBookId(@RequestParam Long bookId) {
        return ResponseEntity.ok(loansServices.getLoanByBookId(bookId));
    }
}
