package com.library.library_project.Internal.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.library.library_project.Internal.Models.Roles;
import com.library.library_project.Internal.Models.TypeRoles;
import com.library.library_project.Internal.Models.Users;
import com.library.library_project.Internal.Repository.RolesRepository;
import com.library.library_project.Internal.Repository.UserRepository;
import com.library.library_project.Internal.Security.jwt.JwtUtil;

import jakarta.transaction.Transactional;
import org.hibernate.Hibernate;

@Service
public class UsersServices {
    private final UserRepository usersRepository;
    private final PasswordEncoder passwordEncoder;
    private final RolesRepository rolesRepository;

    public UsersServices(UserRepository usersRepository, PasswordEncoder passwordEncoder,
            RolesRepository rolesRepository) {
        this.usersRepository = usersRepository;
        this.passwordEncoder = passwordEncoder;
        this.rolesRepository = rolesRepository;
    }

    @Transactional
    public Users registerUsers(String username, String password, TypeRoles role) {
        if (usersRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("El usuario ya existe");
        }

        Users user = new Users();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));

        Roles newRole = new Roles();
        newRole.setUser(user);
        newRole.setRole(role);

        user.setRoles(List.of(newRole));

        usersRepository.save(user);
        rolesRepository.save(newRole);

        return user;
    }

    @Transactional
    public Users getUserWithRoles(String username) {
        Users user = usersRepository.findByUsername(username).orElseThrow();
        Hibernate.initialize(user.getRoles());

        return user;
    }

    @Transactional
    public Optional<String> loginUser(String username, String password) {
        Optional<Users> userOptional = usersRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            Users user = userOptional.get();
            if (passwordEncoder.matches(password, user.getPassword())) {
                String role = user.getRoles().stream()
                        .map(r -> r.getRole().name())
                        .findFirst()
                        .orElse("ROLE_USER");
                JwtUtil jwtUtil = new JwtUtil();
                return Optional.of(jwtUtil.generateToken(Long.toString(user.getId()), username, role));
            }
        }

        return Optional.empty();
    }

    @Transactional
    public void addRoleToUser(String username, String roleName) {
        Users user = usersRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Roles newRole = new Roles();
        newRole.setUser(user);
        TypeRoles role = TypeRoles.valueOf(roleName);
        newRole.setRole(role);

        rolesRepository.save(newRole);
    }
}
