package com.library.library_project.Internal.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.library_project.Internal.Models.Loan;

public interface LoansRepository extends JpaRepository<Loan, Long>{
    List<Loan> findByUserId(Long userId);
    Optional<Loan> findByBookIdAndReturnDateIsNull(Long bookId);

}
