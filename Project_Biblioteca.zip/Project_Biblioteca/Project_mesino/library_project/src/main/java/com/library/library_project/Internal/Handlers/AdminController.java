package com.library.library_project.Internal.Handlers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.library_project.Internal.Models.TypeRoles;
import com.library.library_project.Internal.Services.UsersServices;


@RestController
@RequestMapping("/admin")
public class AdminController {
@Autowired
    private UsersServices usersServices;


    @PostMapping("/addRole")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> addRoleToUser(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        TypeRoles newRole = TypeRoles.valueOf(request.get("role"));

        usersServices.addRoleToUser(username, newRole.name());
        return ResponseEntity.ok("Rol agregado correctamente");
    }
}
