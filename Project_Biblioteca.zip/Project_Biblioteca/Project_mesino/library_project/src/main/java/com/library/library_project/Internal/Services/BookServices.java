package com.library.library_project.Internal.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.library.library_project.Internal.Models.Books;
import com.library.library_project.Internal.Repository.BooksRepository;

@Service
public class BookServices {
    private final BooksRepository booksRepository;

    public BookServices(BooksRepository booksRepository) {
        this.booksRepository = booksRepository;
    }

    public List<Books> getAllBooks() {
        return booksRepository.findAll();
    }

    public List<Books> searchByTitle(String title) {
        return booksRepository.findByTitleContainingIgnoreCase(title);
    }

    public List<Books> searchByAuthor(String author) {
        return booksRepository.findByAuthorContainingIgnoreCase(author);
    }

    public List<Books> searchByGenre(String genre) {
        return booksRepository.findByGenreContainingIgnoreCase(genre);
    }

    public List<Books> searchByYear(int year) {
        return booksRepository.findByYear(year);
    }

    public List<Books> searchByAvailability(boolean available) {
        return booksRepository.findByAvailable(available);
    }

    public Optional<Books> getBookById(Long id) {
        return booksRepository.findById(id);
    }

    public Books createBook(Books book) {
        return booksRepository.save(book);
    }

    public Books updateBook(Long id, Books bookDetails){
        return booksRepository.findById(id).map(book -> {
            book.setTitle(bookDetails.getTitle());
            book.setAuthor(bookDetails.getAuthor());
            book.setGenre(bookDetails.getGenre());
            book.setYear(bookDetails.getYear());
            book.setAvailable(bookDetails.isAvailable());

            return booksRepository.save(book);
        }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }

    public void deleteBook(Long id) {
        booksRepository.deleteById(id);
    }

}
