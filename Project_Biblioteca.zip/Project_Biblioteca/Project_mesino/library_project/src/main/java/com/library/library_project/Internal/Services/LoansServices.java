package com.library.library_project.Internal.Services;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import com.library.library_project.Internal.Models.Books;
import com.library.library_project.Internal.Models.Loan;
import com.library.library_project.Internal.Models.Users;
import com.library.library_project.Internal.Repository.BooksRepository;
import com.library.library_project.Internal.Repository.LoansRepository;
import com.library.library_project.Internal.Repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class LoansServices {
    private final LoansRepository loansRepository;
    private final BooksRepository booksRepository;
    private final UserRepository userRepository;



    public LoansServices(LoansRepository loansRepository, BooksRepository booksRepository, UserRepository userRepository) {
        this.loansRepository = loansRepository;
        this.booksRepository = booksRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public Loan borrowBook(Long userId, Long bookId){
        Users user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Books book = booksRepository.findById(bookId).orElseThrow(() -> new RuntimeException("Libro no encontrado"));

        if (!book.isAvailable()) {
            throw new RuntimeException("El libro no está disponible para préstamo");
        }

        book.setAvailable(false);
        booksRepository.save(book);

        Loan loan = new Loan();
        loan.setUser(user);
        loan.setBook(book);
        loan.setLoanDate(LocalDate.now());

        return loansRepository.save(loan);
    }

    @Transactional
    public Loan returnBook(Long loanId) {
        Loan loan = loansRepository.findById(loanId).orElseThrow(() -> new RuntimeException("Préstamo no encontrado"));

        if (loan.getReturnDate() != null) {
            throw new RuntimeException("El libro ya fue devuelto");
        }

        loan.setReturnDate(LocalDate.now());

        Books book = loan.getBook();
        book.setAvailable(true);
        booksRepository.save(book);

        return loansRepository.save(loan);
    }

    @Transactional
    public Loan getLoanByBookId(Long bookId) {
        return loansRepository.findByBookIdAndReturnDateIsNull(bookId)
                .orElseThrow(() -> new RuntimeException("Préstamo no encontrado para el libro especificado"));
    }
}
