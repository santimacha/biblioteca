package com.library.library_project.Internal.Handlers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.library.library_project.Internal.Models.Books;
import com.library.library_project.Internal.Services.BookServices;

@RestController
@RequestMapping("/books")
public class BookController {
    private final BookServices bookServices;

    public BookController(BookServices bookServices) {
        this.bookServices = bookServices;
    }

    @GetMapping
    public List<Books> getAllBooks() {
        return bookServices.getAllBooks();
    }

    @GetMapping("/search/title")
    public List<Books> searchByTitle(@RequestParam String title) {
        return bookServices.searchByTitle(title);
    }

    @GetMapping("/search/author")
    public List<Books> searchByAuthor(@RequestParam String author) {
        return bookServices.searchByAuthor(author);
    }

    @GetMapping("/search/genre")
    public List<Books> searchByGenre(@RequestParam String genre) {
        return bookServices.searchByGenre(genre);
    }

    @GetMapping("/search/year")
    public List<Books> searchByYear(@RequestParam int year) {
        return bookServices.searchByYear(year);
    }

    @GetMapping("/search/available")
    public List<Books> searchByAvailability(@RequestParam boolean available) {
        return bookServices.searchByAvailability(available);
    }

    @GetMapping("/{id}")
    ResponseEntity<Books> getBookById(@PathVariable Long id) {
        return bookServices.getBookById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    ResponseEntity<Books> createBook(@RequestBody Books book) {
        return ResponseEntity.ok(bookServices.createBook(book));
    }

    @PutMapping("/{id}")
    ResponseEntity<Books> updateBook(@PathVariable Long id, @RequestBody Books bookDetails) {
        return ResponseEntity.ok(bookServices.updateBook(id, bookDetails));
    }

    @DeleteMapping("/{id}")
    ResponseEntity<String> deleteBook(@PathVariable Long id) {
        bookServices.deleteBook(id);
        return ResponseEntity.ok("Book Deleted Successfully");
    }


}
