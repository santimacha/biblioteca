package com.library.library_project.Internal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.library_project.Internal.Models.Roles;

public interface RolesRepository extends JpaRepository<Roles,Long> {
    List<Roles> findByUserId(Long userId);

}
