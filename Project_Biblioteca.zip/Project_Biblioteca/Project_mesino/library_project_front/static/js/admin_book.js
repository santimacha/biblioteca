document.addEventListener('DOMContentLoaded', async () => {
    const booksTableBody = document.querySelector('#books-table tbody');
    const bookForm = document.getElementById('book-form');
    const bookIdInput = document.getElementById('book-id');
    const titleInput = document.getElementById('title');
    const authorInput = document.getElementById('author');
    const genreInput = document.getElementById('genre');
    const yearInput = document.getElementById('year');
    const availabilityInput = document.getElementById('availability');
    const modal = document.getElementById('book-modal');
    const openModalBtn = document.getElementById('open-modal-btn');
    const closeModalBtn = document.querySelector('.close');

    const token = localStorage.getItem('token');
    if (!token) {
        alert('Acceso denegado. Por favor, inicie sesión como administrador.');
        window.location.href = '/library_project_front/templates/user/login.html';
        return;
    }

    const userRole = parseJwt(token).role;
    if (userRole !== 'ROLE_ADMIN') {
        alert('Acceso denegado. Solo los administradores pueden acceder a esta página.');
        window.location.href = '/library_project_front/templates/user/login.html';
        return;
    }

    function logout() {
        const successLink = document.getElementById('successLink');
        localStorage.removeItem('token');
        successLink.click();    
    }

    
    function displayBooks(books) {
        booksTableBody.innerHTML = '';
        books.forEach(book => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td data-label="Título">${book.title}</td>
                <td data-label="Autor">${book.author}</td>
                <td data-label="Género">${book.genre}</td>
                <td data-label="Año">${book.year}</td>
                <td data-label="Disponibilidad">${book.available ? 'Disponible' : 'No disponible'}</td>
                <td data-label="Acciones">
                    <button class="edit-btn" onclick="editBook(${book.id})">Editar</button>
                    <button class="delete-btn" onclick="deleteBook(${book.id})">Eliminar</button>
                </td>
            `;
            booksTableBody.appendChild(row);
        });
    }

    try {
        const books = await getAllBooks();
        displayBooks(books);
    } catch (error) {
        console.error('Error al cargar los libros:', error);
    }

    bookForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const book = {
            title: titleInput.value,
            author: authorInput.value,
            genre: genreInput.value,
            year: yearInput.value,
            available: availabilityInput.value === 'true'
        };

        try {
            if (bookIdInput.value) {
                await updateBook(bookIdInput.value, book);
                alert('Libro actualizado exitosamente');
            } else {
                await createBook(book);
                alert('Libro creado exitosamente');
            }

            bookForm.reset();
            bookIdInput.value = '';
            modal.style.display = 'none';

            const books = await getAllBooks();
            displayBooks(books);
        } catch (error) {
            console.error('Error al guardar el libro:', error);
            alert('Error al guardar el libro');
        }
    });

    window.editBook = async (id) => {
        try {
            const book = await getBookById(id);
            bookIdInput.value = book.id;
            titleInput.value = book.title;
            authorInput.value = book.author;
            genreInput.value = book.genre;
            yearInput.value = book.year;
            availabilityInput.value = book.available ? 'true' : 'false';
            modal.style.display = 'block';
        } catch (error) {
            console.error('Error al obtener el libro:', error);
            alert('Error al obtener el libro');
        }
    };

    window.deleteBook = async (id) => {
        if (confirm('¿Estás seguro de que deseas eliminar este libro?')) {
            try {
                await deleteBook(id);
                alert('Libro eliminado exitosamente');

                // Recargar la lista de libros
                const books = await getAllBooks();
                displayBooks(books);
            } catch (error) {
                console.error('Error al eliminar el libro:', error);
                alert('Error al eliminar el libro');
            }
        }
    };

    async function getAllBooks() {
        const response = await fetch('http://localhost:8080/books', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return await response.json();
    }

    async function getBookById(id) {
        const response = await fetch(`http://localhost:8080/books/${id}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return await response.json();
    }

    async function createBook(book) {
        const response = await fetch('http://localhost:8080/books', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(book)
        });
        return await response.json();
    }

    async function updateBook(id, book) {
        const response = await fetch(`http://localhost:8080/books/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(book)
        });
        return await response.json();
    }

    async function deleteBook(id) {
        await fetch(`http://localhost:8080/books/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
    }

    function parseJwt(token) {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        return JSON.parse(jsonPayload);
    }

    openModalBtn.addEventListener('click', () => {
        modal.style.display = 'block';
    });

    closeModalBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
});