document.getElementById('register-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    try {
        const response = await fetch('http://localhost:8080/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, role })
        });

        if (!response.ok) {
            throw new Error('Error al registrarse');
        }

        const data = await response.json();
        alert('Registro exitoso');
        window.location.href = '/library_project_front/templates/user/login.html';
    } catch (error) {
        console.error('Error:', error);
        alert('Error al registrarse');
    }
});