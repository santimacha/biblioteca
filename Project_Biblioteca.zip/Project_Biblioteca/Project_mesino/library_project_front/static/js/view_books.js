document.addEventListener('DOMContentLoaded', async () => {
    const booksList = document.getElementById('books-list');
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    const searchType = document.getElementById('search-type');

    const successBooks = {true: 'Disponible', false: 'No disponible'};
    
    function displayBooks(books) {
        booksList.innerHTML = '';
        books.forEach(book => {
            const bookItem = document.createElement('li');
            bookItem.innerHTML = `
                <div>
                    <h3>${book.title}</h3>
                    <p>Autor: ${book.author}</p>
                    <p>Género: ${book.genre}</p>
                    <p>Año: ${book.year}</p>
                    <p>Disponibilidad: ${book.available ? successBooks.true : successBooks.false}</p>
                </div>
                <div>
                    <button onclick="borrowBook(${book.id})" ${!book.available ? 'disabled' : ''}>Prestar</button>
                    <button onclick="returnBook(${book.id})" ${book.available ? 'disabled' : ''}>Devolver</button>
                </div>
            `;
            booksList.appendChild(bookItem);
        });
    }

    try {
        const books = await getAllBooks();
        displayBooks(books);
    } catch (error) {
        console.error('Error al cargar los libros:', error);
    }

    searchForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const query = searchInput.value;
        const type = searchType.value;

        try {
            let books;
            if (type === 'available') {
                const available = query.toLowerCase() === 'disponible';
                books = await searchByAvailability(available);
            } else {
                books = await searchBooks(type, query);
            }
            displayBooks(books);
        } catch (error) {
            console.error('Error al buscar los libros:', error);
        }
    });

    window.borrowBook = async (id) => {
        const userId = getUserIdFromToken(); 
        try {
            await borrowBookById(userId, id);
            alert('Libro prestado exitosamente');
            const books = await getAllBooks();
            displayBooks(books);
        } catch (error) {
            console.error('Error al prestar el libro:', error);
            alert('Error al prestar el libro');
        }
    };

    window.returnBook = async (id) => {
        const loanId = await getLoanIdByBookId(id); 
        try {
            await returnBookById(loanId);
            alert('Libro devuelto exitosamente');
            const books = await getAllBooks();
            displayBooks(books);
        } catch (error) {
            console.error('Error al devolver el libro:', error);
            alert('Error al devolver el libro');
        }
    };

    async function getAllBooks() {
        const response = await fetch('http://localhost:8080/books');
        return await response.json();
    }

    async function searchBooks(type, query) {
        const response = await fetch(`http://localhost:8080/books/search/${type}?${type}=${query}`);
        if (!response.ok) {
            throw new Error(`Error en la búsqueda: ${response.statusText}`);
        }
        const text = await response.text();
        return text ? JSON.parse(text) : [];
    }

    async function searchByAvailability(available) {
        const response = await fetch(`http://localhost:8080/books/search/available?available=${available}`);
        if (!response.ok) {
            throw new Error('Error al buscar libros por disponibilidad');
        }
        const books = await response.json();
        return books;
    }

    async function borrowBookById(userId, bookId) {
        const response = await fetch(`http://localhost:8080/loans/borrow?userId=${userId}&bookId=${bookId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        return await response.json();
    }

    async function returnBookById(loanId) {
        const response = await fetch(`http://localhost:8080/loans/return?loanId=${loanId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        return await response.json();
    }

    function getUserIdFromToken() {
        const token = localStorage.getItem('token');
        if (!token) return null;
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.userId;
    }

    async function getLoanIdByBookId(bookId) {
        const response = await fetch(`http://localhost:8080/loans/byBookId?bookId=${bookId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const loan = await response.json();
        return loan.id;
    }
});