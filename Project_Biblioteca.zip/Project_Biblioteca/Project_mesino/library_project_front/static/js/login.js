document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:8080/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        if (!response.ok) {
            throw new Error('Error al iniciar sesión');
        }

        const data = await response.json();
        
        localStorage.setItem('token', data.token);
        alert('Inicio de sesión exitoso');

        
        const userRole = parseJwt(data.token).role;

        
        if (userRole === 'ROLE_ADMIN') {
            window.location.href = '/library_project_front/templates/admin/admin_books.html';
        } else if (userRole === 'ROLE_USER') {
            window.location.href = '/library_project_front/templates/user/books.html';
        } else {
            alert('Rol desconocido');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al iniciar sesión');
    }
});


function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}